new Vue({
    el: "#app",
    data: {
        title: "Start",
        count: "",
        title2: "",
        title3: "Gonder",
        inp: ""

        // console.log("inp");

    },

    // console.log("inp.value");

    methods: {
        test() {
            let x = this.count = Math.floor(Math.random() * 20);
            console.log(x);
            this.title2 = "Salam 1-den, 20-kimi eded daxil edin"
            // this.title3 = "Gonder"

        },
        btn() {
            let i = inp.value
            console.log(i);
            if(i>this.count){
                this.title2="Daxil edilen eded boyukdur"

            }else if(i==this.count){
                this.title2="Siz uddunuz"
               setTimeout(()=>{
                alert("yeni oyuna baslamaq isteyirsiniz?")
                console.log(alert);
               },1000 )
               
            }else{
                this.title2="Daxil edilen eded kicikdir"
            }
        }


    }
})